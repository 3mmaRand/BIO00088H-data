######################################################################
#                                                                    #
#   The effect of 4 different growth media on the growth of          #
#   two E.coli strains.                                              #
#                                                                    #
######################################################################

######################################################################
#                             Overview                               #
######################################################################

# The data in ecoli.xlsx are from an investigation of the growth of 
# two E.coli strains on four different media. The data are measures 
# of optical density which gives an indication of the number of cells
# in the medium. These data were analysed with the aim of making 
# recommendations to researchers about the best media

# The data are organised into two excel worksheets, one for each
# E.coli strain. In each sheet there are two columns:
#    dens: optical density
#    media: one of four different growth media: Circle, Colibroth,
#           Eplus or GoCo    


######################################################################
#                            Set up                                  #
######################################################################

# Packages
library(tidyverse) 
# for summarising and plotting and purrr iteration (note purrr was 
# not covered in the course)
# Hadley Wickham (2017). tidyverse: Easily Install and Load the
# 'Tidyverse'. R package version 1.2.1.
# https://CRAN.R-project.org/package=tidyverse

library(readxl)
# for importing excel worksheets
# Hadley Wickham and Jennifer Bryan (2019). readxl: Read Excel
# Files. R package version 1.3.1.
# https://CRAN.R-project.org/package=readxl


library(viridis)
# for colour palette
# Simon Garnier (2018). viridis: Default Color Maps from 'matplotlib'. 
# R package version 0.5.1.
# https://CRAN.R-project.org/package=viridis

######################################################################
#                    Import and describe data                        #
######################################################################

# assign filepath to a variable
file <- "data-raw/ecoli.xlsx"

# import both worksheets into a single dataframe
ecoli <- file %>% 
  excel_sheets() %>% 
  set_names() %>% 
  map_df(read_excel, 
         path = file, 
         .id = "strain")

# check structure
str(ecoli)
# Classes ‘tbl_df’, ‘tbl’ and 'data.frame':64 obs. of  3 variables:
#   $ strain: chr  "ecoli_strain_2" "ecoli_strain_2" "ecoli_strain_2" 
#   $ dens  : num  0.432 0.732 0.211 0.379 0 
#   $ medium: chr  "Circle" "Circle" "Circle" "Circle" 

# Explore variables 
ecoli %>% group_by(strain, medium) %>% count()
# design is balanced, 8 in each of the treatment combinations
# there are two ecoli strains and 4 media types so 8 x 8 = 64 points
# Groups:   strain, medium [8]
# strain           medium        n
# <chr>            <chr>     <int>
# 1 ecoli_strain_1 Circle        8
# 2 ecoli_strain_1 Colibroth     8
# 3 ecoli_strain_1 Eplus         8
# 4 ecoli_strain_1 GoCo          8
# 5 ecoli_strain_2 Circle        8
# 6 ecoli_strain_2 Colibroth     8
# 7 ecoli_strain_2 Eplus         8
# 8 ecoli_strain_2 GoCo          8

summary(ecoli$dens)
# there doesn't seem to be anything very 
# obviously non-normal (such as lots of values the same, too many 
# zeros, or extreme values. The density variable is a measure we
# would expect to be normally distributed.


######################################################################
#                     Exploratory Analysis                           #
######################################################################

# quick plot
ggplot(data = ecoli, aes(x = medium, y = dens, fill = strain)) +
  geom_boxplot()
# overall - circle perhaps least good; coliboth and eplus good 
# for both strains. GoCo not good for strain_1

# calculate summary statistics
# for strain
ecoli %>% 
  group_by(strain) %>% 
  summarise(mean(dens),
            sd(dens))
# strain_2 grows a little better but seems to mainly due to 
# poor growth of strain_1 of GoCo

# for medium
ecoli %>% 
  group_by(medium) %>% 
  summarise(mean(dens),
            sd(dens)) 
# circle supports least growth

# for the combination, assign to a variable for use in plot later,
# name the columns and include additional summaries: se and n
ecolisum <- ecoli %>% 
  group_by(strain, medium) %>% 
  summarise(mean = mean(dens),
            sd = sd(dens),
            n = length(dens),
            se = sd/sqrt(n))


# conclusion: n = 8 for each treatment combination is quite
# small but the design is balanced, the data have decimal places,
# lack repeated repeated values and extreme values

# We would expect such OD data to be normally distributed therefore
# two-way ANOVA is the desired test if the assumptions are met

######################################################################
#                     Statistical Analysis                           #
######################################################################

# The assumptions of the two-way ANOVA test are 1. the residuals are
# normally distributed and 2. the variances are homogenous.
# These will be investigated in the ANOVA model constructed.

# Carrying out an ANOVA to examine the effect of strain, the effect 
# of medium and whether their effects are independent
mod <- aov(data = ecoli, dens ~ strain * medium)
summary(mod)
# Medium is significant (F = 4.9, d.f. = 3. 56, p = 0.004); 
# strain appears NS but there is a signifcant interaction 
# present (F = 3.3, d.f. = 3, 56, p = 0.026)
# indicating that the effect of medium depends on the strain 
# that is being considered. 

# Tukey Honest Signifcant differences test to establish where 
# signifcant differences bewteen treatment combinations are.
TukeyHSD(mod)
# Significant comparisons listed only
# $medium
#                         diff         lwr        upr     p adj
# Colibroth-Circle  0.18013393  0.01068637 0.34958149 0.0330552
# Eplus-Circle      0.23437500  0.06492744 0.40382256 0.0030356
# Both Colibroth and Eplus are sig better than Circle on average
# (i.e., irrespective of strain)
# $`strain:medium`
#                                                           diff           lwr         upr     p adj
# ecoli_strain_1:Eplus-ecoli_strain_1:Circle         0.285714286  0.0007932328  0.57063534 0.0488889
# ecoli_strain_2:GoCo-ecoli_strain_1:Circle          0.314732143  0.0298110899  0.59965320 0.0206245
# ecoli_strain_1:GoCo-ecoli_strain_1:Eplus          -0.292857143 -0.5777781958 -0.00793609 0.0398209
# ecoli_strain_2:GoCo-ecoli_strain_1:GoCo            0.321875000  0.0369539471  0.60679605 0.0164879

# If you have to use strain_1 Eplus is better than circle and GoCo.
# if you have to use GoCo it's better to use strain_2

######################################################################
#                                 Figure                             #
######################################################################
# note - the post-hoc results need to be added to this figure
fig1 <- ggplot() +
  geom_point(data = ecoli, aes(x = medium, y = dens, colour = strain),
             size = 2,
             position = position_jitterdodge(jitter.width = 0.2, 
                                             jitter.height = 0)) +
  geom_errorbar(data = ecolisum, 
                aes(x = medium, 
                    ymin = mean - se, 
                    ymax = mean + se, 
                    colour = strain),
                width = 0.4, size = 1.2,
                position = position_dodge(width = 1)) +
  geom_errorbar(data = ecolisum, 
                aes(x = medium, 
                    ymin = mean, 
                    ymax = mean, 
                    colour = strain),
                width = 0.3, size = 1.2,
                position = position_dodge(width = 1) ) +
  ylab("Optical Denisty") +
  xlab("Growth Medium") +
  scale_color_manual(values = viridis(2, end = 0.7),
                     labels = c("Strain 1", "Strain 2")) +
  theme_classic() +
  theme(legend.title = element_blank(),
        legend.position = c(0.2, 0.9),
        text = element_text(size = 14, colour = "black"),
        axis.text = element_text(size = 12, colour = "black"),
        axis.line = element_line(size = 1.5),
        axis.ticks = element_line(size = 1.5),
        axis.ticks.length = unit(10,"pt"))
       
# Figure 1. The effect of media on the growth of different 
# strains of E.coli. Error bars are +/- 1 S.E. Comparisons 
# significant under post-hoc testing with Tukey's Honest 
# Significant Difference test

# figure saving settings
units <- "in"
fig_w <- 5
fig_h <- 4
dpi <- 300
device <- "png" 

ggsave("figures/figure1.png", 
       plot = fig1, 
       device = device,
       width = fig_w, 
       height = fig_h,
       units = units,
       dpi = dpi)
